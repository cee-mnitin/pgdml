# RASA CHATBOT ASSIGNMENT

## SUBMITTED BY NITIN MADHAVAN AND PHANEENDRA G

### SOFTWARE VERSION USED
- Python Version 3.7.9 
- Rasa Version 2.2.9
- Tensorflow Version 2.3.2

Further details of packages installed given in requirements.txt
